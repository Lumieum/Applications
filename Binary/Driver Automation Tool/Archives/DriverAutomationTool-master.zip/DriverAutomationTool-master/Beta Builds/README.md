![SCConfigMgr Driver Auatomation Tool](https://i1.wp.com/msendpointmgr.com/wp-content/uploads/2020/04/MSEndpoingMgrDat.jpg?resize=1024%2C641&ssl=1)

# Driver Automation Tool

BETA Testing ONLY - No responsibility taken, use at your own risk!

7-Zip Testing

Replace the 7z.sfx file in your 7-zip 64bit installation folder with the one here.
Replace the DriverAutomationTool.exe
Replace the Invoke-CMApplyDriverPackage.ps1

You can now test 7-zip compressed driver packages.

Version Updates 
6.5.2 - Windows 10 20H2 Support
		Minor bug fixes and updates for XML content parsing
		Notes: Please ensure you are capturing the baseboard values in your HW discovery for known model matching
		
		MD5 Hash - F2B71BBCE547AD53BC5E6A38F7DFFE13
